// Starter JS
console.log('Anime Town starter loaded.');
