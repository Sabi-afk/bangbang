# Anime Town

This ZIP contains the starter project structure.

Because the chat response length was split across many messages, the full CSS/JS
from every part couldn't be automatically merged with perfect fidelity.

Files:
- index.html
- style.css
- script.js

Replace the placeholders with the code blocks from the conversation to continue.
